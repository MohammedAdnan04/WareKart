import { pgTable, text, serial, integer, boolean, json, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tools = pgTable("tools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  overview: text("overview").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  price: integer("price").notNull(),
  logo: text("logo").notNull(),
  features: json("features").notNull(),
  media: json("media").notNull(),
  redirectLink: text("redirect_link").notNull(),
  plan: json("plan").notNull(),
  deployerId: integer("deployer_id").notNull(),
  status: text("status").notNull().default('pending'),
  createdAt: timestamp("created_at").defaultNow(),
});

export const carts = pgTable("carts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  toolId: integer("tool_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  toolId: integer("tool_id").notNull(),
  plan: text("plan").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: z.string(),
  confirmPassword: z.string()
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export const insertToolSchema = z.object({
  name: z.string().min(1, "Tool name is required"),
  overview: z.string().min(1, "Overview is required"),
  description: z.string().min(1, "Description is required"),
  category: z.string().min(1, "Category is required"),
  price: z.number().min(0, "Price must be positive"),
  logo: z.string().min(1, "Logo URL is required"),
  features: z.array(z.string()).min(1, "At least one feature is required"),
  media: z.array(z.string()),
  redirectLink: z.string().url("Must be a valid URL"),
  plan: z.object({
    freeTrial: z.object({
      duration: z.string(),
      features: z.array(z.string())
    }),
    monthly: z.object({
      price: z.number(),
      features: z.array(z.string())
    }),
    yearly: z.object({
      price: z.number(),
      features: z.array(z.string())
    })
  }),
  deployerId: z.number(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Tool = typeof tools.$inferSelect;
export type Cart = typeof carts.$inferSelect;
export type Subscription = typeof subscriptions.$inferSelect;