import { Card, CardContent, CardFooter, CardHeader } from "./card";
import { Button } from "./button";
import { Tool } from "@shared/schema";
import { Link } from "wouter";

export function ToolCard({ tool }: { tool: Tool }) {
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="w-16 h-16 mx-auto mb-4">
          <img src={tool.logo} alt={tool.name} className="w-full h-full object-contain" />
        </div>
        <h3 className="text-lg font-semibold text-center">{tool.name}</h3>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground text-center">{tool.overview}</p>
        <div className="mt-4 flex justify-between items-center">
          <div className="text-sm font-medium">
            ${(tool.price / 100).toFixed(2)}
          </div>
          <div className="text-sm text-muted-foreground">
            {tool.category}
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/tools/${tool.id}`}>
          <Button className="w-full">More Details</Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
