import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "./button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "./navigation-menu";

export function Navbar() {
  const { user, logoutMutation } = useAuth();

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="text-2xl font-bold">WareKart</a>
        </Link>

        <NavigationMenu>
          <NavigationMenuList className="space-x-4">
            <NavigationMenuItem className="px-2">
              <Link href="/tools">
                <NavigationMenuLink className="cursor-pointer hover:text-primary transition-colors">
                  All Tools
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>

            {user ? (
              <>
                <NavigationMenuItem className="px-2">
                  <Link href="/deploy">
                    <NavigationMenuLink className="cursor-pointer hover:text-primary transition-colors">
                      Deploy Tools
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem className="px-2">
                  <Link href="/profile">
                    <NavigationMenuLink className="cursor-pointer hover:text-primary transition-colors">
                      Profile
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem className="px-2">
                  <Button
                    variant="ghost"
                    onClick={() => logoutMutation.mutate()}
                    disabled={logoutMutation.isPending}
                    className="hover:text-primary transition-colors"
                  >
                    Logout
                  </Button>
                </NavigationMenuItem>
              </>
            ) : (
              <NavigationMenuItem className="px-2">
                <Link href="/auth">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                    Get Started
                  </Button>
                </Link>
              </NavigationMenuItem>
            )}
          </NavigationMenuList>
        </NavigationMenu>
      </div>
    </header>
  );
}