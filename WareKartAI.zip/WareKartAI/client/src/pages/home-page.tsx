import { Input } from "@/components/ui/input";
import { Navbar } from "@/components/ui/navbar";
import { TrendingTools } from "@/components/ui/trending-tools";
import { Search } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navbar />
      
      <main className="container mx-auto px-4 py-16 space-y-16">
        {/* Hero Section */}
        <section className="text-center space-y-8">
          <h1 className="text-4xl md:text-6xl font-bold">
            Discover & Deploy AI Tools
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Your marketplace for AI tools, SaaS products, and digital assets
          </p>
          
          <div className="max-w-xl mx-auto relative">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input 
              placeholder="Search for tools..." 
              className="pl-10 h-12"
            />
          </div>
        </section>

        {/* Trending Tools Section */}
        <section>
          <TrendingTools />
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold mb-4">About WareKart</h3>
              <p className="text-sm text-muted-foreground">
                Your one-stop marketplace for discovering and deploying AI tools, SaaS products, and digital assets.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact Us</h3>
              <p className="text-sm text-muted-foreground">
                Email: support@warekart.com<br />
                Phone: (555) 123-4567
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-foreground">Twitter</a>
                <a href="#" className="text-muted-foreground hover:text-foreground">LinkedIn</a>
                <a href="#" className="text-muted-foreground hover:text-foreground">GitHub</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
