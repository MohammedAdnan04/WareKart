import { useQuery, useMutation } from "@tanstack/react-query";
import { Tool, Cart, Subscription } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Navbar } from "@/components/ui/navbar";
import { Button } from "@/components/ui/button";
import { ToolCard } from "@/components/ui/tool-card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const { data: cart, isLoading: isCartLoading } = useQuery<Cart[]>({
    queryKey: ["/api/cart"],
  });

  const { data: subscriptions, isLoading: isSubscriptionsLoading } = useQuery<
    Subscription[]
  >({
    queryKey: ["/api/subscriptions"],
  });

  const { data: tools } = useQuery<Tool[]>({
    queryKey: ["/api/tools"],
  });

  const removeFromCartMutation = useMutation({
    mutationFn: async (toolId: number) => {
      await apiRequest("DELETE", `/api/cart/${toolId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Removed from cart",
        description: "Item has been removed from your cart",
      });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/user/change-password", {
        currentPassword,
        newPassword,
      });
    },
    onSuccess: () => {
      toast({
        title: "Password updated",
        description: "Your password has been changed successfully",
      });
      setCurrentPassword("");
      setNewPassword("");
    },
  });

  // Filter tools for the cart, subscriptions, and deployed sections
  const cartTools = tools?.filter((tool) =>
    cart?.some((item) => item.toolId === tool.id)
  );
  
  const subscribedTools = tools?.filter((tool) =>
    subscriptions?.some((sub) => sub.toolId === tool.id)
  );

  const deployedTools = tools?.filter(
    (tool) => tool.deployerId === user?.id
  );

  const plans = [
    {
      name: "Free Trial",
      price: "0",
      duration: "10 days",
      features: ["Access to basic tools", "Limited usage", "Community support"],
    },
    {
      name: "Monthly",
      price: "29",
      duration: "per month",
      features: ["Access to all tools", "Unlimited usage", "Priority support"],
    },
    {
      name: "Yearly",
      price: "299",
      duration: "per year",
      features: [
        "Access to all tools",
        "Unlimited usage",
        "Priority support",
        "2 months free",
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* User Details */}
          <Card>
            <CardHeader>
              <CardTitle>Profile</CardTitle>
              <CardDescription>Manage your account details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Username</label>
                <p className="text-muted-foreground">{user?.username}</p>
              </div>
              <div>
                <label className="text-sm font-medium">Role</label>
                <p className="text-muted-foreground">{user?.role}</p>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline">Change Password</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Change Password</DialogTitle>
                    <DialogDescription>
                      Enter your current password and a new password to update it.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Current Password
                      </label>
                      <Input
                        type="password"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">New Password</label>
                      <Input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      onClick={() => changePasswordMutation.mutate()}
                      disabled={changePasswordMutation.isPending}
                    >
                      {changePasswordMutation.isPending && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Update Password
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>

          {/* Tools Management */}
          <Tabs defaultValue="cart">
            <TabsList className="grid grid-cols-3 w-full max-w-md">
              <TabsTrigger value="cart">Cart</TabsTrigger>
              <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
              <TabsTrigger value="deployed">Deployed Tools</TabsTrigger>
            </TabsList>

            <TabsContent value="cart">
              <Card>
                <CardHeader>
                  <CardTitle>Shopping Cart</CardTitle>
                  <CardDescription>Tools added to your cart</CardDescription>
                </CardHeader>
                <CardContent>
                  {isCartLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin" />
                    </div>
                  ) : cartTools?.length === 0 ? (
                    <p className="text-center py-8 text-muted-foreground">
                      No items in cart
                    </p>
                  ) : (
                    <div className="grid gap-6">
                      {cartTools?.map((tool) => (
                        <div key={tool.id} className="flex justify-between items-center">
                          <div className="flex-1">
                            <ToolCard tool={tool} />
                          </div>
                          <Button
                            variant="destructive"
                            onClick={() => removeFromCartMutation.mutate(tool.id)}
                            disabled={removeFromCartMutation.isPending}
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="subscriptions">
              <Card>
                <CardHeader>
                  <CardTitle>Subscriptions</CardTitle>
                  <CardDescription>Your active subscriptions</CardDescription>
                </CardHeader>
                <CardContent>
                  {isSubscriptionsLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin" />
                    </div>
                  ) : subscribedTools?.length === 0 ? (
                    <p className="text-center py-8 text-muted-foreground">
                      No active subscriptions
                    </p>
                  ) : (
                    <div className="grid gap-6">
                      {subscribedTools?.map((tool) => (
                        <ToolCard key={tool.id} tool={tool} />
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="deployed">
              <Card>
                <CardHeader>
                  <CardTitle>Deployed Tools</CardTitle>
                  <CardDescription>Tools you have submitted</CardDescription>
                </CardHeader>
                <CardContent>
                  {deployedTools?.length === 0 ? (
                    <p className="text-center py-8 text-muted-foreground">
                      No tools deployed
                    </p>
                  ) : (
                    <div className="grid gap-6">
                      {deployedTools?.map((tool) => (
                        <div key={tool.id}>
                          <ToolCard tool={tool} />
                          <p className="mt-2 text-sm text-muted-foreground">
                            Status: {tool.status}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Plans & Pricing */}
          <Card>
            <CardHeader>
              <CardTitle>Plans & Pricing</CardTitle>
              <CardDescription>Choose the right plan for you</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                {plans.map((plan) => (
                  <Card key={plan.name}>
                    <CardHeader>
                      <CardTitle>{plan.name}</CardTitle>
                      <CardDescription>
                        ${plan.price} {plan.duration}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {plan.features.map((feature, i) => (
                          <li key={i} className="text-sm text-muted-foreground">
                            ✓ {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
