import { useQuery, useMutation } from "@tanstack/react-query";
import { Tool } from "@shared/schema";
import { useParams, useLocation } from "wouter";
import { Navbar } from "@/components/ui/navbar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function ToolDetailsPage() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: tool, isLoading } = useQuery<Tool>({
    queryKey: [`/api/tools/${id}`],
  });

  const addToCartMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/cart/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Added to cart",
        description: "The tool has been added to your cart",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
  });

  const purchaseMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/subscriptions/${id}`, { plan: "monthly" });
    },
    onSuccess: () => {
      toast({
        title: "Purchase successful",
        description: "You now have access to this tool",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions"] });
    },
  });

  const handleAction = (action: "cart" | "purchase") => {
    if (!user) {
      setLocation("/auth");
      return;
    }

    if (action === "cart") {
      addToCartMutation.mutate();
    } else {
      purchaseMutation.mutate();
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex items-center justify-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </div>
    );
  }

  if (!tool) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold">Tool not found</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Tool Info */}
          <div className="space-y-6">
            <div className="w-24 h-24 mx-auto md:mx-0">
              <img 
                src={tool.logo} 
                alt={tool.name} 
                className="w-full h-full object-contain"
              />
            </div>

            <div>
              <h1 className="text-3xl font-bold">{tool.name}</h1>
              <p className="text-muted-foreground mt-2">{tool.overview}</p>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center">
                {Array(5).fill(0).map((_, i) => (
                  <Star
                    key={i}
                    className={cn(
                      "w-4 h-4",
                      i < 4 ? "text-yellow-400 fill-yellow-400" : "text-muted-foreground"
                    )}
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">
                Category: {tool.category}
              </span>
            </div>

            <div className="prose max-w-none">
              <h2 className="text-xl font-semibold">Description</h2>
              <p>{tool.description}</p>

              <h2 className="text-xl font-semibold mt-6">Features</h2>
              <ul>
                {(tool.features as string[]).map((feature, i) => (
                  <li key={i}>{feature}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Action Card */}
          <div className="md:pl-8">
            <div className="sticky top-8 bg-card p-6 rounded-lg border">
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-3xl font-bold">
                    ${(tool.price / 100).toFixed(2)}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Monthly subscription
                  </p>
                </div>

                <div className="space-y-4">
                  <Button
                    className="w-full"
                    onClick={() => handleAction("purchase")}
                    disabled={purchaseMutation.isPending}
                  >
                    {purchaseMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : null}
                    Purchase Now
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => handleAction("cart")}
                    disabled={addToCartMutation.isPending}
                  >
                    {addToCartMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : null}
                    Add to Cart
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
