import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertToolSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Navbar } from "@/components/ui/navbar";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Loader2, Upload, Check } from "lucide-react";
import { useState } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";


const categories = [
  "AI Tools",
  "SaaS Products",
  "Templates",
  "Add-ons & Plugins",
  "Digital Assets",
  "Development Tools",
  "Security Software",
  "Others",
];

export default function DeployPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [showSuccess, setShowSuccess] = useState(false);

  const form = useForm({
    resolver: zodResolver(insertToolSchema),
    defaultValues: {
      name: "",
      overview: "",
      description: "",
      category: "",
      price: 0,
      logo: "",
      features: [],
      media: [],
      redirectLink: "",
      plan: {
        freeTrial: {
          duration: "10 days",
          features: ["Basic access", "Limited usage"]
        },
        monthly: {
          price: 0,
          features: ["Full access", "Priority support"]
        },
        yearly: {
          price: 0,
          features: ["Full access", "Priority support", "2 months free"]
        }
      },
      deployerId: user?.id,
    },
  });

  const deployMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/tools", data);
      return res.json();
    },
    onSuccess: () => {
      setShowSuccess(true);
      toast({
        title: "Tool submitted for approval",
        description: "Your tool is now pending review by our team.",
      });
      // Redirect after 3 seconds
      setTimeout(() => setLocation("/profile"), 3000);
    },
  });

  const onSubmit = (data: any) => {
    // Convert features from comma-separated string to array
    const features = data.features.split(",").map((f: string) => f.trim());
    // Convert price to cents
    const price = Math.round(parseFloat(data.price) * 100);

    deployMutation.mutate({
      ...data,
      features,
      price,
      deployerId: user?.id,
    });
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-lg mx-auto text-center space-y-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold">Tool Submitted Successfully!</h1>
            <p className="text-muted-foreground">
              Your tool is now pending review. We'll notify you once it's approved.
            </p>
            <div className="animate-pulse">
              <p className="text-sm text-muted-foreground">
                Redirecting to your profile...
              </p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Deploy Your Tool</h1>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>
                    Provide the essential details about your tool
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tool Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="overview"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Overview</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Detailed Description</FormLabel>
                        <FormControl>
                          <Textarea {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="redirectLink"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tool Redirect Link</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="https://" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Features & Media */}
              <Card>
                <CardHeader>
                  <CardTitle>Features & Media</CardTitle>
                  <CardDescription>
                    Add key features and upload media content
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="features"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Key Features (comma-separated)</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="logo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Logo Upload</FormLabel>
                        <FormControl>
                          <div className="flex gap-4 items-center">
                            <Input {...field} />
                            <Button type="button" variant="outline" size="icon">
                              <Upload className="h-4 w-4" />
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="media"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Photos & Videos</FormLabel>
                        <FormControl>
                          <div className="flex gap-4 items-center">
                            <Input {...field} multiple />
                            <Button type="button" variant="outline" size="icon">
                              <Upload className="h-4 w-4" />
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Pricing & Plans Selection */}
              <Card>
                <CardHeader>
                  <CardTitle>Select a Plan</CardTitle>
                  <CardDescription>
                    Choose a pricing plan for your tool
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup defaultValue="monthly" className="grid lg:grid-cols-3 gap-8">
                    {/* Free Trial Plan */}
                    <div>
                      <RadioGroupItem
                        value="free-trial"
                        id="free-trial"
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor="free-trial"
                        className="flex flex-col h-full p-6 gap-6 rounded-lg border bg-card hover:bg-accent peer-checked:border-primary cursor-pointer"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <h3 className="font-semibold">Free Trial</h3>
                            <span className="text-sm text-muted-foreground">10 Days</span>
                          </div>
                          <div className="mt-2 text-2xl font-bold">Free</div>
                          <div className="mt-2 text-sm text-muted-foreground">
                            Perfect for trying out our tools
                          </div>
                        </div>
                        <ul className="flex-1 mt-2 space-y-2 text-sm leading-relaxed">
                          {form.watch('plan.freeTrial.features').map((feature, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <Check className="h-4 w-4 text-primary" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </Label>
                    </div>

                    {/* Monthly Plan */}
                    <div>
                      <RadioGroupItem
                        value="monthly"
                        id="monthly"
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor="monthly"
                        className="flex flex-col h-full p-6 gap-6 rounded-lg border bg-card hover:bg-accent peer-checked:border-primary cursor-pointer"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <h3 className="font-semibold">Monthly</h3>
                            <span className="text-sm text-muted-foreground">Monthly billing</span>
                          </div>
                          <div className="mt-2">
                            <span className="text-2xl font-bold">
                              ${form.watch('plan.monthly.price')}
                            </span>
                            <span className="text-sm text-muted-foreground">/month</span>
                          </div>
                          <div className="mt-2 text-sm text-muted-foreground">
                            Great for regular usage
                          </div>
                        </div>
                        <ul className="flex-1 mt-2 space-y-2 text-sm leading-relaxed">
                          {form.watch('plan.monthly.features').map((feature, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <Check className="h-4 w-4 text-primary" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </Label>
                    </div>

                    {/* Yearly Plan */}
                    <div>
                      <RadioGroupItem
                        value="yearly"
                        id="yearly"
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor="yearly"
                        className="flex flex-col h-full p-6 gap-6 rounded-lg border bg-card hover:bg-accent peer-checked:border-primary cursor-pointer relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 px-3 py-1 text-xs font-medium text-primary-foreground bg-primary rounded-bl">
                          Best value
                        </div>
                        <div>
                          <div className="flex items-center justify-between">
                            <h3 className="font-semibold">Yearly</h3>
                            <span className="text-sm text-muted-foreground">Annual billing</span>
                          </div>
                          <div className="mt-2">
                            <span className="text-2xl font-bold">
                              ${form.watch('plan.yearly.price')}
                            </span>
                            <span className="text-sm text-muted-foreground">/year</span>
                          </div>
                          <div className="mt-2 text-sm text-primary">Save up to 20%</div>
                        </div>
                        <ul className="flex-1 mt-2 space-y-2 text-sm leading-relaxed">
                          {form.watch('plan.yearly.features').map((feature, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <Check className="h-4 w-4 text-primary" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>

              <Button
                type="submit"
                className="w-full"
                disabled={deployMutation.isPending}
              >
                {deployMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Deploy Tool
              </Button>
            </form>
          </Form>
        </div>
      </main>
    </div>
  );
}