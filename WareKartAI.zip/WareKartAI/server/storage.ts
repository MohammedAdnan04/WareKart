import { User, InsertUser, Tool, Cart, Subscription } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getTools(): Promise<Tool[]>;
  getTool(id: number): Promise<Tool | undefined>;
  createTool(tool: Omit<Tool, "id" | "status" | "createdAt">): Promise<Tool>;
  updateToolStatus(id: number, status: string): Promise<Tool>;

  getCart(userId: number): Promise<Cart[]>;
  addToCart(userId: number, toolId: number): Promise<Cart>;
  removeFromCart(userId: number, toolId: number): Promise<void>;

  getSubscriptions(userId: number): Promise<Subscription[]>;
  addSubscription(userId: number, toolId: number, plan: string): Promise<Subscription>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tools: Map<number, Tool>;
  private carts: Map<number, Cart>;
  private subscriptions: Map<number, Subscription>;
  private currentId: number;
  readonly sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.tools = new Map();
    this.carts = new Map();
    this.subscriptions = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    this.initializeSampleTools();
  }

  private initializeSampleTools() {
    const sampleTools = [
      {
        id: this.currentId++,
        name: "AI Code Assistant",
        overview: "Powerful AI-powered code completion and suggestions",
        description: "Advanced code assistant that helps developers write better code faster with real-time suggestions and automated refactoring.",
        category: "AI Tools",
        price: 2999,
        logo: "https://cdn-icons-png.flaticon.com/512/2621/2621040.png",
        features: ["Code completion", "Refactoring suggestions", "Multiple language support", "GitHub integration"],
        media: [],
        deployerId: 1,
        status: "active",
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        name: "Analytics Dashboard",
        overview: "Real-time analytics and reporting platform",
        description: "Comprehensive analytics solution that provides real-time insights into your business metrics with customizable dashboards.",
        category: "SaaS Products",
        price: 4999,
        logo: "https://cdn-icons-png.flaticon.com/512/1283/1283243.png",
        features: ["Real-time analytics", "Custom dashboards", "Export reports", "Team collaboration"],
        media: [],
        deployerId: 1,
        status: "active",
        createdAt: new Date(),
      },
      {
        id: this.currentId++,
        name: "Security Scanner",
        overview: "Automated security vulnerability scanner",
        description: "Advanced security tool that automatically scans your applications for vulnerabilities and provides detailed reports.",
        category: "Security Software",
        price: 3999,
        logo: "https://cdn-icons-png.flaticon.com/512/2716/2716652.png",
        features: ["Vulnerability scanning", "Automated reports", "Real-time alerts", "Compliance checks"],
        media: [],
        deployerId: 1,
        status: "active",
        createdAt: new Date(),
      }
    ];

    sampleTools.forEach(tool => this.tools.set(tool.id, tool));
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  async getTools(): Promise<Tool[]> {
    return Array.from(this.tools.values());
  }

  async getTool(id: number): Promise<Tool | undefined> {
    return this.tools.get(id);
  }

  async createTool(tool: Omit<Tool, "id" | "status" | "createdAt">): Promise<Tool> {
    const id = this.currentId++;
    const now = new Date();
    const newTool: Tool = { ...tool, id, status: 'pending', createdAt: now };
    this.tools.set(id, newTool);
    return newTool;
  }

  async updateToolStatus(id: number, status: string): Promise<Tool> {
    const tool = await this.getTool(id);
    if (!tool) throw new Error("Tool not found");
    const updatedTool = { ...tool, status };
    this.tools.set(id, updatedTool);
    return updatedTool;
  }

  async getCart(userId: number): Promise<Cart[]> {
    return Array.from(this.carts.values()).filter(
      (cart) => cart.userId === userId,
    );
  }

  async addToCart(userId: number, toolId: number): Promise<Cart> {
    const id = this.currentId++;
    const now = new Date();
    const cart: Cart = { id, userId, toolId, createdAt: now };
    this.carts.set(id, cart);
    return cart;
  }

  async removeFromCart(userId: number, toolId: number): Promise<void> {
    const cartItem = Array.from(this.carts.values()).find(
      (cart) => cart.userId === userId && cart.toolId === toolId,
    );
    if (cartItem) {
      this.carts.delete(cartItem.id);
    }
  }

  async getSubscriptions(userId: number): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values()).filter(
      (sub) => sub.userId === userId,
    );
  }

  async addSubscription(userId: number, toolId: number, plan: string): Promise<Subscription> {
    const id = this.currentId++;
    const now = new Date();
    const subscription: Subscription = { id, userId, toolId, plan, createdAt: now };
    this.subscriptions.set(id, subscription);
    return subscription;
  }
}

export const storage = new MemStorage();