import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertToolSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Tools routes
  app.get("/api/tools", async (req, res) => {
    const tools = await storage.getTools();
    res.json(tools);
  });

  app.get("/api/tools/:id", async (req, res) => {
    const tool = await storage.getTool(parseInt(req.params.id));
    if (!tool) return res.status(404).send("Tool not found");
    res.json(tool);
  });

  app.post("/api/tools", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const result = insertToolSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json(result.error);
    const tool = await storage.createTool({
      ...result.data,
      deployerId: req.user!.id,
    });
    res.status(201).json(tool);
  });

  // Cart routes
  app.get("/api/cart", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const cart = await storage.getCart(req.user!.id);
    res.json(cart);
  });

  app.post("/api/cart/:toolId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const cart = await storage.addToCart(req.user!.id, parseInt(req.params.toolId));
    res.status(201).json(cart);
  });

  app.delete("/api/cart/:toolId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    await storage.removeFromCart(req.user!.id, parseInt(req.params.toolId));
    res.sendStatus(200);
  });

  // Subscription routes
  app.get("/api/subscriptions", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const subscriptions = await storage.getSubscriptions(req.user!.id);
    res.json(subscriptions);
  });

  app.post("/api/subscriptions/:toolId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const { plan } = req.body;
    if (!plan) return res.status(400).send("Plan is required");
    const subscription = await storage.addSubscription(
      req.user!.id,
      parseInt(req.params.toolId),
      plan,
    );
    res.status(201).json(subscription);
  });

  const httpServer = createServer(app);
  return httpServer;
}
